<?php
include 'database.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    die('Вы не авторизованы!');
}
$user_id = $_SESSION['user_id'];
$query = "SELECT role FROM users WHERE id = $user_id";
$result = $db->query($query);
$user = $result->fetch_assoc();
if ($user['role'] !== 'admin') {
    die('У вас нет прав для просмотра списка пользователей!');
}
$result = $db->query("SELECT username, email FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<header>
        <button onclick="document.location.href = '/index.php'" class="headerLink">Регистрация</button>
        <button onclick="document.location.href = '/login.php'" class="headerLink">Авторизация</button>
        <button onclick="document.location.href = '/edit.php'" class="headerLink">Редактирование аккаунта</button>
        <button onclick="document.location.href = '/admin.php'" class="headerLink">Администратор</button>
        <button onclick="document.location.href = '/create_post.php'" class="headerLink">Создать пост</button>
        <button onclick="document.location.href = '/posts_view.php'" class="headerLink">Все посты</button>
    </header>
    <h2>Страница администратора</h2>
    <?php
    if ($result->num_rows > 0) {
        echo '<table>';
        echo '<tr><th>Имя</th><th>Email</th></tr>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr><td>' . $row['username'] .  '</td><td>' . $row['email'] . '</td></tr>';
        }
        echo '</table>';
    } else {
        echo 'Пользователи отсутствуют.';
    }
    ?>
</body>
</html>
