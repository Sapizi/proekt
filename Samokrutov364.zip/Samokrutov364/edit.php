<?php
include 'database.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    die('Вы не авторизованы!');
}
$username = "SELECT username from users WHERE id = " . $_SESSION['user_id'];
$result = $db->query($username);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $current_password = $_POST['current_password'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $new_password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;
    $query = "SELECT password FROM users WHERE id = $user_id";
    $result = $db->query($query);
    if ($result && $row = $result->fetch_assoc()) {
        if (!password_verify($current_password, $row['password'])) {
            die('Ошибка: текущий пароль введен неверно.');
        }
    } else {
        die('Ошибка: пользователь не найден.');
    }
    $query = "UPDATE users SET username = '$username', email = '$email'";
    if ($new_password) {
        $query .= ", password = '$new_password'";
    }
    $query .= " WHERE id = $user_id";
    if ($db->query($query)) {
        echo 'Данные успешно обновлены!';
    } else {
        echo 'Ошибка: ' . $db->error;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <button onclick="document.location.href = '/index.php'" class="headerLink">Регистрация</button>
        <button onclick="document.location.href = '/login.php'" class="headerLink">Авторизация</button>
        <button onclick="document.location.href = '/edit.php'" class="headerLink">Редактирование аккаунта</button>
        <button onclick="document.location.href = '/admin.php'" class="headerLink">Администратор</button>
    </header>
    <h2>Редактирование аккаунта</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Имя пользователя" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Новый пароль">
        <input type="password" name="current_password" placeholder="Текущий пароль" required>
        <button type="submit">Обновить</button>
    </form>
    <p>Вы зашлии под именем
        <?= $result->fetch_assoc()['username'] ?>
    </p>
</body>
</html>