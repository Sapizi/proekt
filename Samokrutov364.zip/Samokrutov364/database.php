<?php
$db = new mysqli('151.248.115.10', 'root','Kwuy1mSu4Y','is64_Samokrutov') or die('error');
?>